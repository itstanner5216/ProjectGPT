#!/usr/bin/env python3
"""
ProjectGPT Core Controller
Universal Skill Integration Framework (USIF) - Main Entry Point

This controller automatically loads, registers, and initializes all modular AI skills.
"""

import os
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional


class SkillRegistry:
    def __init__(self):
        self.skills: Dict[str, Dict[str, Any]] = {}
        self.skill_order: List[str] = []
        self.event_handlers: Dict[str, List[str]] = {}
        
    def register_skill(self, skill_name: str, config: Dict[str, Any], entry_point: Path) -> bool:
        """Register a skill in the framework"""
        try:
            self.skills[skill_name] = {
                'name': skill_name,
                'config': config,
                'entry_point': entry_point,
                'status': 'registered',
                'loaded_at': datetime.now().isoformat()
            }
            self.skill_order.append(skill_name)
            return True
        except Exception as e:
            print(f"❌ Failed to register {skill_name}: {e}")
            return False
    
    def get_skill_info(self, skill_name: str) -> Dict[str, Any]:
        """Get information about a registered skill"""
        return self.skills.get(skill_name, {})
    
    def list_skills(self) -> List[str]:
        """List all registered skills"""
        return self.skill_order


class UniversalSkillIntegrationFramework:
    def __init__(self, skills_dir: str = "skills"):
        self.skills_dir = Path(skills_dir)
        self.registry = SkillRegistry()
        self.optimization_profile = None
        self.automation_graph = None
        
    def discover_skills(self) -> List[Path]:
        """Discover all skill directories"""
        if not self.skills_dir.exists():
            print(f"❌ Skills directory not found: {self.skills_dir}")
            return []
        
        skill_dirs = [d for d in self.skills_dir.iterdir() if d.is_dir() and not d.name.startswith('.')]
        return sorted(skill_dirs)
    
    def load_skill_config(self, skill_dir: Path) -> Dict[str, Any]:
        """Load skill configuration from config.json"""
        config_path = skill_dir / "config.json"
        if not config_path.exists():
            return {}
        
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️  Warning: Could not load config for {skill_dir.name}: {e}")
            return {}
    
    def find_entry_point(self, skill_dir: Path) -> Optional[Path]:
        """Find the main entry point file (.md or .py)"""
        candidates = [
            skill_dir / f"{skill_dir.name.replace('-', '_')}.md",
            skill_dir / f"{skill_dir.name.replace('-', '_')}.py",
            skill_dir / "entry_point.md",
            skill_dir / "entry_point.py",
        ]
        
        for candidate in candidates:
            if candidate.exists():
                return candidate
        
        md_files = list(skill_dir.glob("*.md"))
        if md_files:
            return md_files[0]
        
        py_files = list(skill_dir.glob("*.py"))
        if py_files:
            return py_files[0]
        
        return None
    
    def initialize_skill(self, skill_name: str) -> bool:
        """Initialize a specific skill"""
        skill_info = self.registry.get_skill_info(skill_name)
        if not skill_info:
            return False
        
        config = skill_info['config']
        
        if skill_name == 'optimization-profile':
            print(f"🔧 Initializing {skill_name}...")
            print(f"   └─ Tuning reasoning depth and caching...")
            self.optimization_profile = skill_info
            return True
        
        elif skill_name == 'automation-graph':
            print(f"🔗 Initializing {skill_name}...")
            print(f"   └─ Setting up event routing between skills...")
            self.automation_graph = skill_info
            return True
        
        else:
            print(f"📦 Initialized {skill_name}")
            return True
    
    def load_all_skills(self) -> int:
        """Discover and load all skills"""
        print("=" * 60)
        print("ProjectGPT - Universal Skill Integration Framework (USIF)")
        print("=" * 60)
        print()
        
        skill_dirs = self.discover_skills()
        
        if not skill_dirs:
            print("❌ No skills found in skills directory")
            return 0
        
        print(f"📂 Discovered {len(skill_dirs)} skill packages\n")
        
        priority_skills = ['optimization-profile', 'automation-graph']
        regular_skills = []
        
        for skill_dir in skill_dirs:
            skill_name = skill_dir.name
            if skill_name in priority_skills:
                continue
            regular_skills.append(skill_dir)
        
        load_order = []
        for name in priority_skills:
            matching = [d for d in skill_dirs if d.name == name]
            if matching:
                load_order.append(matching[0])
        load_order.extend(regular_skills)
        
        loaded_count = 0
        
        for skill_dir in load_order:
            skill_name = skill_dir.name
            print(f"Loading: {skill_name}")
            
            config = self.load_skill_config(skill_dir)
            entry_point = self.find_entry_point(skill_dir)
            
            if not entry_point:
                print(f"   ⚠️  No entry point found, skipping...")
                continue
            
            if self.registry.register_skill(skill_name, config, entry_point):
                print(f"   ✓ Registered: {entry_point.name}")
                loaded_count += 1
            
            print()
        
        return loaded_count
    
    def initialize_all_skills(self):
        """Initialize all registered skills in order"""
        print("=" * 60)
        print("Initializing Skills")
        print("=" * 60)
        print()
        
        for skill_name in self.registry.list_skills():
            self.initialize_skill(skill_name)
            print()
    
    def print_summary(self):
        """Print summary of loaded skills"""
        print("=" * 60)
        print("✅ ProjectGPT System Ready")
        print("=" * 60)
        print()
        print(f"Total Skills Registered: {len(self.registry.list_skills())}")
        print()
        print("Active Skills:")
        for i, skill_name in enumerate(self.registry.list_skills(), 1):
            skill_info = self.registry.get_skill_info(skill_name)
            config = skill_info.get('config', {})
            version = config.get('version', '1.0')
            print(f"  {i}. {skill_name} (v{version})")
        
        print()
        print("System Components:")
        if self.optimization_profile:
            print("  ✓ Optimization Profile: Active (tuning performance)")
        if self.automation_graph:
            print("  ✓ Automation Graph: Active (routing events)")
        
        print()
        print("=" * 60)
        print("ProjectGPT is now running. All skills are loaded and ready.")
        print("=" * 60)


def main():
    """Main entry point for ProjectGPT"""
    usif = UniversalSkillIntegrationFramework()
    
    loaded_count = usif.load_all_skills()
    
    if loaded_count == 0:
        print("\n❌ No skills were loaded. Exiting.")
        sys.exit(1)
    
    usif.initialize_all_skills()
    
    usif.print_summary()
    
    print("\n💡 Keep this process running to maintain ProjectGPT services.")
    print("   Press Ctrl+C to stop.\n")
    
    try:
        import time
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n🛑 Shutting down ProjectGPT...")
        print("All skills unloaded. Goodbye!\n")


if __name__ == "__main__":
    main()
