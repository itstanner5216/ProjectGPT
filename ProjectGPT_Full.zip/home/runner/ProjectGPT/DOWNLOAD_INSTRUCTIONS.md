# How to Save Your ProjectGPT Files

## Quick Download Methods

### Option 1: Download Individual Files (Easiest)
1. In the file explorer (left sidebar), right-click any file
2. Click "Download"
3. File saves to your computer

**Key files to download:**
- `project_gpt_core.py` - Main controller
- `replit.md` - Project documentation
- `test_skill_integration.py` - Integration test
- `.gitignore` - Git configuration

### Option 2: Download the `skills/` folder
Each skill folder contains:
- `skills/optimization-profile/`
- `skills/automation-graph/`
- `skills/deep-research/`
- `skills/deal-finder/`
- `skills/knowledge-orchestrator/`
- `skills/prompt-factory/`

Download each folder individually by right-clicking.

### Option 3: Use Git Clone
Clone this entire project to your computer:

1. Open terminal/command prompt on your computer
2. Run: `git clone <your-replit-git-url>`
3. All files download automatically

Your Replit git URL is typically in the format:
`https://github.com/replit/<username>/<projectname>`

### Option 4: Manual Backup
Copy/paste file contents:
1. Open any file in Replit
2. Select All (Ctrl+A / Cmd+A)
3. Copy (Ctrl+C / Cmd+C)
4. Paste into a local text editor
5. Save with the same filename

## Project Structure to Recreate

```
ProjectGPT/
├── project_gpt_core.py
├── test_skill_integration.py
├── replit.md
├── .gitignore
└── skills/
    ├── optimization-profile/
    │   ├── optimization_profile.md
    │   ├── config.json
    │   ├── README.md
    │   └── data/
    ├── automation-graph/
    │   ├── automation_graph.md
    │   ├── config.json
    │   ├── README.md
    │   └── data/
    ├── deep-research/
    │   ├── deep_research.md
    │   ├── config.json
    │   ├── README.md
    │   └── data/
    ├── deal-finder/
    │   ├── deal_finder.md
    │   ├── config.json
    │   ├── README.md
    │   └── data/
    ├── knowledge-orchestrator/
    │   ├── knowledge_orchestrator.md
    │   ├── config.json
    │   ├── README.md
    │   └── data/
    └── prompt-factory/
        ├── SKILL.md
        ├── config.json
        ├── README.md
        └── data/
```

## Running Locally

After downloading, install Python 3.11+ and run:
```bash
python3 project_gpt_core.py
```

All skills will auto-register and initialize!
