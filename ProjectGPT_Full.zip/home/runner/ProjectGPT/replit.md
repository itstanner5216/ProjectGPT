# ProjectGPT - Universal Skill Integration Framework

## Overview
ProjectGPT is a modular AI skill orchestration system that uses the Universal Skill Integration Framework (USIF) to dynamically load, register, and coordinate specialized AI capabilities.

## Project Structure

```
ProjectGPT/
├── project_gpt_core.py          # Main controller & USIF implementation
├── skills/                       # Modular skill packages
│   ├── optimization-profile/     # Performance tuning & resource optimization
│   │   ├── optimization_profile.md
│   │   ├── config.json
│   │   ├── README.md
│   │   └── data/                # Runtime logs
│   ├── automation-graph/         # Event routing between skills
│   │   ├── automation_graph.md
│   │   ├── config.json
│   │   ├── README.md
│   │   └── data/
│   ├── deep-research/            # Comprehensive research reports
│   │   ├── deep_research.md
│   │   ├── config.json
│   │   ├── README.md
│   │   └── data/
│   ├── deal-finder/              # Product deal aggregation & comparison
│   │   ├── deal_finder.md
│   │   ├── config.json
│   │   ├── README.md
│   │   └── data/
│   ├── knowledge-orchestrator/   # Hybrid data coordination & merging
│   │   ├── knowledge_orchestrator.md
│   │   ├── config.json
│   │   ├── README.md
│   │   └── data/
│   └── prompt-factory/           # Professional prompt generation
│       ├── SKILL.md
│       ├── config.json
│       ├── README.md
│       ├── templates/
│       ├── scripts/
│       ├── examples/
│       └── data/
└── attached_assets/              # Original skill packages (archived)
```

## Active Skills

### 1. Optimization Profile (v1.0)
- **Purpose**: Meta-tuner for reasoning depth, verbosity, and resource allocation
- **Execution**: Runs on startup
- **Scope**: Subordinate (inherits tone from parent protocol)

### 2. Automation Graph (v1.1)
- **Purpose**: Event routing and dependency management between skills
- **Features**: Queued event handling, stage dependencies, O(1) routing
- **Execution**: Active continuously for inter-skill communication

### 3. Deep Research Extension (v5.9)
- **Purpose**: Multi-phase research pipeline with triple-source verification
- **Features**: 6-phase execution, confidence tiering, mechanistic reasoning
- **Output**: Professional analytical reports (1200-2500 words)

### 4. DealFinder Extension (v1.0)
- **Purpose**: Real-time deal aggregation across 15+ marketplaces
- **Features**: Specification compliance, link validation, price verification
- **Coverage**: Amazon, Newegg, eBay, Best Buy, Walmart, Target, B&H Photo, etc.

### 5. Knowledge Orchestrator (v1.0)
- **Purpose**: Coordinates hybrid data queries and merges external research into core reasoning
- **Features**: Multi-source coordination, conflict resolution, confidence scoring
- **Integration**: Works with Deep Research, Automation Graph, and Optimization Profile

### 6. Prompt Factory (v1.0)
- **Purpose**: Production-ready AI prompt generation
- **Features**: 69 professional presets, 7-point validation, multi-format support
- **Speed**: < 2 minutes per prompt, max 7 questions

## System Architecture

### Universal Skill Integration Framework (USIF)
The USIF automatically:
1. Discovers skill packages in the `skills/` directory
2. Loads configuration from `config.json` files
3. Registers skills in priority order (optimization-profile → automation-graph → others)
4. Initializes skills with proper dependencies
5. Manages skill lifecycle and event routing

### Priority Loading Order
1. **optimization-profile** - Tunes system performance first
2. **automation-graph** - Sets up event routing infrastructure
3. All other skills - Load in alphabetical order

## Running ProjectGPT

### Automatic Startup
The workflow is configured to run automatically:
```bash
python3 project_gpt_core.py
```

### Manual Start
```bash
python3 project_gpt_core.py
```

### Verification
Check console output for:
- ✅ All 6 skills registered
- ✓ Optimization Profile: Active
- ✓ Automation Graph: Active

## Configuration

Each skill contains:
- **Entry Point**: `.md` or `.py` file with skill logic
- **config.json**: Metadata and registration settings
- **README.md**: Documentation and usage instructions
- **data/**: Directory for runtime logs and state

## Development Notes

### Adding New Skills
1. Create directory in `skills/` folder
2. Add skill entry point (`.md` or `.py`)
3. Create `config.json` with metadata
4. Add `README.md` documentation
5. Create `data/` directory for logs
6. Restart ProjectGPT

### Skill Configuration Schema
```json
{
  "skill_name": "skill-name",
  "version": "1.0",
  "execution_scope": "Subordinate",
  "auto_register": true,
  "cache_skill": true,
  "memory_scope": "session-temporary"
}
```

## Recent Changes

### November 11, 2025
- Initial ProjectGPT setup complete
- Structured workspace with 6 modular skills
- USIF implementation with auto-discovery
- Workflow configured for automatic startup
- All skills successfully registered and initialized
- Optimization Profile tuning system performance
- Automation Graph routing events between skills
- Knowledge Orchestrator added for hybrid data coordination

## User Preferences
- Clean, organized directory structure
- Modular skill architecture
- Automatic initialization on startup
- Clear verification messages

## Technical Details
- **Language**: Python 3.11
- **Framework**: Universal Skill Integration Framework (USIF)
- **Architecture**: Modular, event-driven skill system
- **Workflow**: Continuous background process
- **Dependencies**: None (self-contained)
